-- Modern Betaflight Init - Fixed Structure
-- File: ui_init.lua

-- Definiamo la tabella di ritorno ESATTAMENTE come la vuole Betaflight
local returnTable = { t = "Initializing...", f = nil }

-- Variabili di stato interne
local state = 0
local apiVersionReceived = false
local vtxTablesReceived = false
local mcuIdReceived = false
local boardInfoReceived = false
local getApiVersion, getVtxTables, getMCUId, getBoardInfo

-- === COLORI MODERNI ===
local COL_BG       = lcd.RGB(20, 20, 20)    -- Sfondo Scurissimo
local COL_HEADER   = lcd.RGB(255, 140, 0)   -- Arancione Betaflight
local COL_TEXT_HI  = lcd.RGB(255, 255, 255) -- Testo Bianco
local COL_TEXT_BLK = lcd.RGB(0, 0, 0)       -- Testo Nero

-- Funzione grafica interna
local function drawHeader()
    local h = 25
    if not radio.highRes then h = 12 end
    lcd.drawFilledRectangle(0, 0, LCD_W, h, COL_HEADER)
    local txtOpt = 0
    if radio.highRes then txtOpt = DBLSIZE end
    lcd.drawText(5, (h/2) - (radio.highRes and 12 or 4), "Betaflight Loading", txtOpt + COL_TEXT_BLK)
end

-- Questa è la funzione principale che viene eseguita ciclicamente
local function init()
    -- 1. Disegna lo Sfondo Moderno (Così non vedi nero)
    lcd.drawFilledRectangle(0, 0, LCD_W, LCD_H, COL_BG)
    drawHeader()
    
    -- 2. Scrivi lo stato attuale al centro
    lcd.drawText(10, radio.yMinLimit + (radio.highRes and 40 or 20), returnTable.t, COL_TEXT_HI + BLINK)

    -- 3. Logica originale di caricamento (INTATTA)
    if getRSSI() == 0 then
        returnTable.t = "Waiting for connection..."
    elseif not apiVersionReceived then
        getApiVersion = getApiVersion or assert(loadScript("api_version.lua"))()
        returnTable.t = "Checking API Version..." -- Testo personalizzato
        apiVersionReceived = getApiVersion.f()
        if apiVersionReceived then
            getApiVersion = nil
            collectgarbage()
        end
    elseif not mcuIdReceived and apiVersion >= 1.42 then
        getMCUId = getMCUId or assert(loadScript("mcu_id.lua"))()
        returnTable.t = "Reading MCU ID..."
        mcuIdReceived = getMCUId.f()
        if mcuIdReceived then
            getMCUId = nil
            local f = loadScript("VTX_TABLES/"..mcuId..".lua")
            if f and f() then
                vtxTablesReceived = true
                f = nil
            end
            collectgarbage()
            f = loadScript("BOARD_INFO/"..mcuId..".lua")
            if f and f() then
                boardInfoReceived = true
                f = nil
            end
            collectgarbage()
        end
    elseif not vtxTablesReceived and apiVersion >= 1.42 then
        getVtxTables = getVtxTables or assert(loadScript("vtx_tables.lua"))()
        returnTable.t = "Loading VTX Tables..."
        vtxTablesReceived = getVtxTables.f()
        if vtxTablesReceived then
            getVtxTables = nil
            collectgarbage()
        end
    elseif not boardInfoReceived and apiVersion >= 1.44 then
        getBoardInfo = getBoardInfo or assert(loadScript("board_info.lua"))()
        returnTable.t = "Loading Board Info..."
        boardInfoReceived = getBoardInfo.f()
        if boardInfoReceived then
            getBoardInfo = nil
            collectgarbage()
        end
    else
        return true -- Tutto caricato!
    end
    
    -- Se siamo qui, non abbiamo ancora finito
    return apiVersionReceived and vtxTablesReceived and mcuId and boardInfoReceived
end

-- Assegna la funzione alla tabella
returnTable.f = init

-- Restituisce la tabella (NON la funzione)
return returnTable