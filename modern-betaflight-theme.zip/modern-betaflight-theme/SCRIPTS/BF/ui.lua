-- Modern Betaflight UI - Smart Layout & Label Fixing
-- Replacement for ui.lua

-- === CONFIGURAZIONE COLORI ===
local C_BG       = lcd.RGB(0, 0, 0)         -- Sfondo Nero
local C_ORANGE   = lcd.RGB(255, 140, 0)     -- Betaflight Orange
local C_WHITE    = lcd.RGB(255, 255, 255)   -- Bianco
local C_GRAY_L   = lcd.RGB(180, 180, 180)   -- Grigio Chiaro
local C_GRAY_D   = lcd.RGB(90, 90, 90)      -- Grigio Scuro
local C_DARK     = lcd.RGB(25, 25, 25)      -- Sfondo Card
local C_L_ORANGE   = lcd.RGB(255, 100, 0)     -- Betaflight light Orange

-- Variabili Sistema
local uiStatus = { init = 1, mainMenu = 2, pages = 3, confirm = 4 }
local pageStatus = { display = 1, editing = 2, saving = 3 }
local uiMsp = { reboot = 68, eepromWrite = 250 }

local uiState = uiStatus.init
local prevUiState
local pageState = pageStatus.display
local requestTimeout = 80
local currentPage = 1
local currentField = 1
local saveTS = 0
local saveTimeout = protocol.saveTimeout
local saveRetries = 0
local saveMaxRetries = protocol.saveMaxRetries
local popupMenuActive = 1
local killEnterBreak = 0
local mainMenuScrollY = 0
local scrollIndex = 1 
local PageFiles, Page, init, popupMenu

local backgroundFill = C_BG
local foregroundColor = C_WHITE

-- === LOGICA HELPER ===
local function clipValue(val,min,max)
    if val < min then val = min elseif val > max then val = max end
    return val
end

local function incMax(val, inc, base)
    return ((val + inc + base - 1) % base) + 1
end

-- === STANDARD MSP LOGIC ===
local function saveSettings()
    if Page.values then
        local payload = Page.values
        if Page.preSave then payload = Page.preSave(Page) end
        protocol.mspWrite(Page.write, payload)
        saveTS = getTime()
        if pageState == pageStatus.saving then saveRetries = saveRetries + 1
        else pageState = pageStatus.saving; saveRetries = 0 end
    end
end

local function invalidatePages()
    Page = nil; pageState = pageStatus.display; saveTS = 0; collectgarbage()
end

local function rebootFc() protocol.mspRead(uiMsp.reboot); invalidatePages() end
local function eepromWrite() protocol.mspRead(uiMsp.eepromWrite) end

local function confirm(page)
    prevUiState = uiState; uiState = uiStatus.confirm; invalidatePages()
    currentField = 1; Page = assert(loadScript(page))(); collectgarbage()
end

local function createPopupMenu()
    popupMenuActive = 1; popupMenu = {}
    if uiState == uiStatus.pages then
        popupMenu[#popupMenu + 1] = { t = "Save Page", f = saveSettings }
        popupMenu[#popupMenu + 1] = { t = "Reload", f = invalidatePages }
    end
    popupMenu[#popupMenu + 1] = { t = "Reboot FC", f = rebootFc }
    popupMenu[#popupMenu + 1] = { t = "Acc Calib", f = function() confirm("CONFIRM/acc_cal.lua") end }
    if apiVersion >= 1.42 then
        popupMenu[#popupMenu + 1] = { t = "VTX Tables", f = function() confirm("CONFIRM/vtx_tables.lua") end }
    end
end

local function processMspReply(cmd,rx_buf)
    if not Page or not rx_buf then return end
    if cmd == Page.write then
        if Page.eepromWrite then eepromWrite() else invalidatePages() end
    elseif cmd == uiMsp.eepromWrite then
        if Page.reboot then rebootFc() end
        invalidatePages()
    elseif cmd == Page.read and #rx_buf > 0 then
        Page.values = rx_buf
        for i=1,#Page.fields do
            if #Page.values >= Page.minBytes then
                local f = Page.fields[i]
                if f.vals then
                    f.value = 0
                    for idx=1, #f.vals do
                        local raw_val = Page.values[f.vals[idx]] or 0
                        raw_val = bit32.lshift(raw_val, (idx-1)*8)
                        f.value = bit32.bor(f.value, raw_val)
                    end
                    local bits = #f.vals * 8
                    if f.min and f.min < 0 and bit32.btest(f.value, bit32.lshift(1, bits - 1)) then
                        f.value = f.value - (2 ^ bits)
                    end
                    f.value = f.value/(f.scale or 1)
                end
            end
        end
        if Page.postLoad then Page.postLoad(Page) end
    end
end

local function incPage(inc) currentPage = incMax(currentPage, inc, #PageFiles); currentField = 1; invalidatePages() end
local function incField(inc) currentField = clipValue(currentField + inc, 1, #Page.fields) end
local function incMainMenu(inc) currentPage = clipValue(currentPage + inc, 1, #PageFiles) end
local function incPopupMenu(inc) popupMenuActive = clipValue(popupMenuActive + inc, 1, #popupMenu) end

local function requestPage()
    if Page.read and ((not Page.reqTS) or (Page.reqTS + requestTimeout <= getTime())) then
        Page.reqTS = getTime(); protocol.mspRead(Page.read)
    end
end

-- === SMART LABEL FINDER ===
-- Cerca un'etichetta (Label) che sia sulla stessa riga del campo (Field)
-- Questo risolve il problema di ROLL/PITCH/YAW che sono label separate
local function getSmartTitle(field, fieldIndex)
    -- Se il campo ha già un titolo, usalo
    if field.t then return field.t end
    
    -- Altrimenti cerca nella lista Labels di Betaflight
    -- Cerca una label che sia vicina verticalmente (stessa riga originale)
    if Page.labels then
        for i=1, #Page.labels do
            local lbl = Page.labels[i]
            -- Tolleranza di 4 pixel sull'asse Y originale
            if math.abs(lbl.y - field.y) < 6 then
                -- Trovata! Usa questa come titolo
                return lbl.t
            end
        end
    end
    return "" -- Nessun titolo trovato
end

-- === HEADER ===
local function drawScreenTitle(screenTitle)
    local h = 42 
    if not radio.highRes then h = 20 end
    
    lcd.drawFilledRectangle(0, 0, LCD_W, h, C_ORANGE)
    
    local txtOpt = 0
    if radio.highRes then txtOpt = DBLSIZE end
    local yCenter = (h/2) - (radio.highRes and 16 or 6)
    
    lcd.drawText(8, yCenter, screenTitle, txtOpt + lcd.RGB(0,0,0))
    
    return h 
end

-- === RENDERIZZAZIONE LISTA INTELLIGENTE ===
local function drawScreen()
    lcd.drawFilledRectangle(0, 0, LCD_W, LCD_H, C_BG)
    
    local headerH = drawScreenTitle("Betaflight / " .. (Page.title or "Menu"))
    local startY = headerH + (radio.highRes and 6 or 2)
    
    local rowH = 25 
    if radio.highRes then rowH = 64 end 

    -- Scroll Logic Fixata
    local visibleRows = math.floor((LCD_H - startY) / rowH)
    if currentField > (scrollIndex + visibleRows - 1) then
        scrollIndex = currentField - visibleRows + 1
    elseif currentField < scrollIndex then
        scrollIndex = currentField
    end
    if scrollIndex < 1 then scrollIndex = 1 end
    
    -- 1. DISEGNA SOLO LE LABEL "HEADER" (Quelle in alto, tipo "P I D")
    -- Ignoriamo le label che sono "dentro" la lista per non sovrapporre
    local firstFieldY = Page.fields[1] and Page.fields[1].y or 0
    for i=1,#Page.labels do
        local f = Page.labels[i]
        -- Disegna solo se la label originale era SOPRA il primo campo (quindi è un'intestazione)
        if f.y < (firstFieldY - 5) then
            -- Posiziona l'intestazione sotto l'header arancione
            local y = headerH + 2
            -- Se siamo in LowRes, adattiamo la X per centrare meglio le colonne P I D
            lcd.drawText(f.x, y, f.t, SMLSIZE + C_GRAY_L)
        end
    end
    
    -- 2. DISEGNA I CAMPI (CARD)
    for i=1,#Page.fields do
        local relIndex = i - scrollIndex
        local y = startY + (relIndex * rowH)
        
        -- Disegna con margine di sicurezza per lo scroll (disegna parzialmente fuori sopra/sotto)
        if y >= (headerH - rowH) and y < LCD_H then
            local f = Page.fields[i]
            local val = "---"
            if f.value then
                if f.upd and Page.values then f.upd(Page) end
                val = f.value
                if f.table and f.table[f.value] then val = f.table[f.value] end
            end

            -- Recupera il Titolo "Intelligente" (Field name o Label vicina)
            local title = getSmartTitle(f, i)

            local isSelected = (i == currentField)
            local dist = math.abs(i - currentField)
            local cardY = y + 2
            local cardH = rowH - 4
            
            if isSelected then
                -- === CARD SELEZIONATA (STACKED) ===
                -- Sfondo
                local bgCol = C_DARK
                local borderCol = C_ORANGE
                local txtTitleCol = C_ORANGE
                local txtValCol = C_L_ORANGE
                
                if pageState == pageStatus.editing then
                     bgCol = C_ORANGE
                     borderCol = C_WHITE
                     txtTitleCol = lcd.RGB(0,0,0)
                     txtValCol = lcd.RGB(0,0,0)
                end
                
                lcd.drawFilledRectangle(2, cardY, LCD_W-4, cardH, bgCol)
                lcd.drawRectangle(2, cardY, LCD_W-4, cardH, borderCol, 2)

                -- TESTO STACKED (Titolo alto SX, Valore basso DX)
                if radio.highRes then
                    lcd.drawText(10, cardY + 5, title, MIDSIZE + txtTitleCol)
                    -- Valore gigante
                    lcd.drawText(LCD_W - 10, cardY + 28, tostring(val), DBLSIZE + RIGHT + txtValCol)
                else
                    lcd.drawText(5, cardY+2, title, txtTitleCol)
                    lcd.drawText(LCD_W-5, cardY+2, tostring(val), RIGHT + txtValCol)
                end

            else
                -- === CARD NON SELEZIONATA (RIGA SINGOLA) ===
                local txtColor = C_GRAY_D
                local txtSize = 0 
                if dist == 1 then 
                    txtColor = C_GRAY_L 
                    if radio.highRes then txtSize = MIDSIZE end
                end

                -- Centratura Verticale
                local fontH = 12
                if txtSize == MIDSIZE then fontH = 18 end
                local txtY = y + (rowH - fontH)/2 

                -- Nome
                lcd.drawText(8, txtY, title, txtColor + txtSize) 
                
                -- Valore (Sempre a destra, mai sovrapposto)
                lcd.drawText(LCD_W - 8, txtY, tostring(val), txtColor + txtSize + RIGHT)
            end
        end
    end
end

local function incValue(inc)
    local f = Page.fields[currentField]
    local scale = f.scale or 1
    local mult = f.mult or 1
    f.value = clipValue(f.value + inc*mult/scale, (f.min or 0)/scale, (f.max or 255)/scale)
    f.value = math.floor(f.value*scale/mult + 0.5)*mult/scale
    for idx=1, #f.vals do
        Page.values[f.vals[idx]] = bit32.rshift(math.floor(f.value*scale + 0.5), (idx-1)*8)
    end
    if f.upd and Page.values then f.upd(Page) end
end

-- === POPUP MENU ===
local function drawPopupMenu()
    local w = radio.MenuBox.w
    local h_line = radio.MenuBox.h_line
    if radio.highRes then h_line = 45 end 
    
    local h = #popupMenu * h_line + 45
    local x = (LCD_W - w) / 2
    local y = (LCD_H - h) / 2

    lcd.drawFilledRectangle(x, y, w, h, C_BG)
    lcd.drawRectangle(x, y, w, h, C_ORANGE, 2) 
    
    lcd.drawFilledRectangle(x, y, w, 35, C_ORANGE)
    lcd.drawText(x+10, y+8, "OPTIONS", lcd.RGB(0,0,0) + DBLSIZE)

    for i,e in ipairs(popupMenu) do
        local yPos = y + 45 + (i-1)*h_line
        local attr = C_GRAY_D
        local sz = MIDSIZE
        
        if popupMenuActive == i then
            lcd.drawRectangle(x+5, yPos-2, w-10, h_line-4, C_ORANGE)
            attr = C_WHITE
            sz = DBLSIZE 
        end
        lcd.drawText(x + 15, yPos, e.t, attr + sz)
    end
end

local function run_ui(event)
    if popupMenu then
        drawPopupMenu()
        if event == EVT_VIRTUAL_EXIT then popupMenu = nil
        elseif event == EVT_VIRTUAL_PREV then incPopupMenu(-1)
        elseif event == EVT_VIRTUAL_NEXT then incPopupMenu(1)
        elseif event == EVT_VIRTUAL_ENTER then
            if killEnterBreak == 1 then killEnterBreak = 0 else popupMenu[popupMenuActive].f(); popupMenu = nil end
        end
    elseif uiState == uiStatus.init then
        lcd.clear(); lcd.drawFilledRectangle(0,0,LCD_W,LCD_H, C_BG)
        drawScreenTitle("Betaflight Setup")
        init = init or assert(loadScript("ui_init.lua"))()
        lcd.drawText(10, 80, init.t, C_WHITE + BLINK + MIDSIZE)
        if not init.f() then return 0 end
        init = nil; PageFiles = assert(loadScript("pages.lua"))(); invalidatePages()
        uiState = prevUiState or uiStatus.mainMenu; prevUiState = nil
        
    elseif uiState == uiStatus.mainMenu then
        if event == EVT_VIRTUAL_EXIT then return 2
        elseif event == EVT_VIRTUAL_NEXT then incMainMenu(1)
        elseif event == EVT_VIRTUAL_PREV then incMainMenu(-1)
        elseif event == EVT_VIRTUAL_ENTER then uiState = uiStatus.pages
        elseif event == EVT_VIRTUAL_ENTER_LONG then killEnterBreak = 1; createPopupMenu() end
        
        lcd.drawFilledRectangle(0, 0, LCD_W, LCD_H, C_BG)
        local headerH = drawScreenTitle("Betaflight Config")
        local startY = headerH + 6
        
        local rowH = 25
        if radio.highRes then rowH = 64 end
        
        local visibleRows = math.floor((LCD_H - startY) / rowH)
        if currentPage > (mainMenuScrollY + visibleRows - 1) then
            mainMenuScrollY = currentPage - visibleRows + 1
        elseif currentPage <= mainMenuScrollY then
            mainMenuScrollY = currentPage - 1
        end
        
        for i=1, #PageFiles do
            local relIndex = (i - 1) - mainMenuScrollY
            local y = startY + (relIndex * rowH)
            
            if y >= headerH and y < LCD_H then
                local isSel = (currentPage == i)
                local dist = math.abs(currentPage - i)
                local txtCol = C_GRAY_D
                local txtSize = 0
                
                if isSel then
                    -- Main Menu
                    lcd.drawFilledRectangle(4, y+2, LCD_W-8, rowH-4, C_DARK)
                    lcd.drawRectangle(4, y+2, LCD_W-8, rowH-4, C_ORANGE)
                    txtCol = C_L_ORANGE
                    if radio.highRes then txtSize = DBLSIZE else txtSize = BOLD end
                    lcd.drawText(20, y + (rowH/2) - 14, PageFiles[i].title, txtCol + txtSize)
                else 
                    if dist == 1 then
                        txtCol = C_GRAY_L
                        if radio.highRes then txtSize = MIDSIZE end
                    end
                    lcd.drawText(20, y + (rowH/2) - (isSel and 14 or 10), PageFiles[i].title, txtCol + txtSize)
                end
            end
        end
        
    elseif uiState == uiStatus.pages then
        if pageState == pageStatus.saving then
            if saveTS + saveTimeout < getTime() then
                if saveRetries < saveMaxRetries then saveSettings()
                else pageState = pageStatus.display; invalidatePages() end
            end
        elseif pageState == pageStatus.display then
            if event == EVT_VIRTUAL_PREV_PAGE then incPage(-1); killEvents(event) 
            elseif event == EVT_VIRTUAL_NEXT_PAGE then incPage(1)
            elseif event == EVT_VIRTUAL_PREV or event == EVT_VIRTUAL_PREV_REPT then incField(-1)
            elseif event == EVT_VIRTUAL_NEXT or event == EVT_VIRTUAL_NEXT_REPT then incField(1)
            elseif event == EVT_VIRTUAL_ENTER then
                if Page then
                    local f = Page.fields[currentField]
                    if Page.values and f.vals and Page.values[f.vals[#f.vals]] and not f.ro then pageState = pageStatus.editing end
                end
            elseif event == EVT_VIRTUAL_ENTER_LONG then killEnterBreak = 1; createPopupMenu()
            elseif event == EVT_VIRTUAL_EXIT then invalidatePages(); currentField = 1; uiState = uiStatus.mainMenu; return 0 end
        elseif pageState == pageStatus.editing then
            if event == EVT_VIRTUAL_EXIT or event == EVT_VIRTUAL_ENTER then
                if Page.fields[currentField].postEdit then Page.fields[currentField].postEdit(Page) end
                pageState = pageStatus.display
            elseif event == EVT_VIRTUAL_INC or event == EVT_VIRTUAL_INC_REPT then incValue(1)
            elseif event == EVT_VIRTUAL_DEC or event == EVT_VIRTUAL_DEC_REPT then incValue(-1) end
        end
        if not Page then Page = assert(loadScript("PAGES/"..PageFiles[currentPage].script))(); collectgarbage() end
        if not Page.values and pageState == pageStatus.display then requestPage() end
        
        drawScreen()
        
        if pageState == pageStatus.saving then
            local saveMsg = "Saving..."
            if saveRetries > 0 then saveMsg = "Retrying" end
            
            -- === MODIFICA DIMENSIONI BOX ===
            local boxW = 260  -- Larghezza aumentata (era 100)
            local boxH = 70   -- Altezza aumentata (era 40)
            
            -- Disegna il rettangolo centrato
            lcd.drawFilledRectangle((LCD_W/2)-(boxW/2), (LCD_H/2)-(boxH/2), boxW, boxH, C_ORANGE)
            
            -- Disegna il testo (Centrato manualmente)
            -- Spostiamo la X indietro di 70px per centrare la scritta "Saving..."
            lcd.drawText((LCD_W/2)-70, (LCD_H/2)-12, saveMsg, lcd.RGB(0,0,0) + BLINK + DBLSIZE)
        end
        
    elseif uiState == uiStatus.confirm then
        drawScreen()
        local bx, by = 10, LCD_H - 40
        lcd.drawFilledRectangle(bx, by, LCD_W-20, 30, C_ORANGE)
        lcd.drawText(bx+10, by+6, "ENTER to Confirm", lcd.RGB(0,0,0) + DBLSIZE)
        if event == EVT_VIRTUAL_ENTER then uiState = uiStatus.init; init = Page.init; invalidatePages()
        elseif event == EVT_VIRTUAL_EXIT then invalidatePages(); uiState = prevUiState; prevUiState = nil end
    end
    
    mspProcessTxQ()
    processMspReply(mspPollReply())
    return 0
end

return run_ui