return {
    margin       = 2,
    indent       = 6,
    lineSpacing  = 8,
    listSpacing  = { line = 8, field = 88 },
    tableSpacing = { row = 10, col = 30, header = 8 },
}
