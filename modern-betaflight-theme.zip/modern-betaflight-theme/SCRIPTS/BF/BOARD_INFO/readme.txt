Board info downloaded from the flight controller will be stored in this folder.
